/**
 * Global App Config
 *
 * */

export default {
    materialColors: ['#4CAF50', '#FF5722', '#607D8B', '#C0CA33', '#03A9F4', '#009688', '#673AB7', '#ee0290', '#D32F2F'],

    imgurClientId: 'a63e2ee9b4e48be',
};
