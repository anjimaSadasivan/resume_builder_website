export const Colors = {
    olive: '#4f5a27',
    green: '#68933b',
    gray: '#938b76',
    lemon: '#fce0a7',
    yellow: '#f5d369',
    greenLight: '#ccc86e',
};
