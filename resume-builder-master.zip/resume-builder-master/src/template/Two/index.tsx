import React from 'react';

// import styles from './two.module.scss';

class Template extends React.Component {
    render() {
        return (
            <>
                <div>two</div>
            </>
        );
    }
}

/* Export Component =============================== */
export default Template;
