import WorkExperience from './WorkExperience';
import Skills from './Skills';
import Education from './Education';
import Photo from './Photo';

export { WorkExperience, Skills, Education, Photo };
